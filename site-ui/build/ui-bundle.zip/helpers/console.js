'use strict'

module.exports = (data) => JSON.stringify(data)
